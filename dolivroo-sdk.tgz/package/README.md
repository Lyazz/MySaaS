# Dolivroo Node.js SDK

Official Node.js/TypeScript SDK for the Dolivroo Delivery API.

## Installation

```bash
npm install @dolivroo/sdk
# or
yarn add @dolivroo/sdk
# or
pnpm add @dolivroo/sdk
```

## Quick Start

```typescript
import Dolivroo from '@dolivroo/sdk';

const client = new Dolivroo('your-api-key');

// Create a parcel
const parcel = await client.parcels.create('yalidine', {
    customer: {
        first_name: 'Mohamed',
        last_name: 'Ali',
        phone: '0555000000'
    },
    destination: {
        wilaya: 'Alger',
        commune: 'Bab El Oued'
    },
    package: {
        products: 'T-Shirt x2'
    },
    payment: {
        amount: 2500
    }
});

console.log('Tracking ID:', parcel.tracking_id);
```

## API Reference

### Parcels

```typescript
// Create
await client.parcels.create('yalidine', orderData);

// Get details
await client.parcels.get('TRACKING123', 'yalidine');

// List all
await client.parcels.list('yalidine', page, perPage);

// Update
await client.parcels.update('TRACKING123', 'yalidine', updates);

// Cancel
await client.parcels.cancel('TRACKING123', 'yalidine');

// Get shipping label
await client.parcels.getLabel('TRACKING123', 'yalidine');

// Track
await client.parcels.track('TRACKING123', 'yalidine');
```

### Rates

```typescript
// Get rates for a route
await client.rates.get('yalidine', 'Alger', 'Oran');

// Compare all providers
await client.rates.compare('Alger', 'Oran');
```

### Wilayas

```typescript
// List all wilayas
await client.wilayas.list();

// List for specific provider
await client.wilayas.list('yalidine');
```

### Bulk Operations

```typescript
// Create multiple parcels
await client.bulk.createParcels('yalidine', [order1, order2, order3]);
```

## Error Handling

```typescript
import Dolivroo, { AuthenticationError, ValidationError, RateLimitError } from '@dolivroo/sdk';

try {
    await client.parcels.create('yalidine', order);
} catch (error) {
    if (error instanceof AuthenticationError) {
        console.log('Invalid API key');
    } else if (error instanceof ValidationError) {
        console.log('Validation errors:', error.data);
    } else if (error instanceof RateLimitError) {
        console.log('Rate limited, try again later');
    }
}
```

## Configuration

```typescript
const client = new Dolivroo('your-api-key', {
    baseUrl: 'https://custom-api.com/api/v1/unified', // Optional
    timeout: 60000 // Optional, in ms
});
```

## License

MIT
