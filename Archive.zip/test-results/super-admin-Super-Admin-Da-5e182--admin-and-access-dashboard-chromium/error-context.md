# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - img [ref=e7]
      - heading "Super Admin Login" [level=1] [ref=e9]
      - paragraph [ref=e10]: Sign in to access the platform dashboard
    - generic [ref=e11]:
      - generic [ref=e12]:
        - generic [ref=e13]:
          - generic [ref=e14]: Email
          - textbox "superadmin@example.com" [ref=e15]
        - generic [ref=e16]:
          - generic [ref=e17]: Password
          - textbox "••••••••" [ref=e18]
        - button "Sign In" [ref=e19] [cursor=pointer]
      - link "← Back to main site" [ref=e21] [cursor=pointer]:
        - /url: /
  - generic:
    - img
  - generic:
    - generic:
      - generic:
        - button "Go to parent" [disabled]
        - button "Open in editor"
        - button "Close"
  - generic [ref=e22]:
    - button "Toggle Nuxt DevTools" [ref=e23] [cursor=pointer]:
      - img [ref=e24]
    - generic "Page load time" [ref=e27]:
      - generic [ref=e28]: "64"
      - generic [ref=e29]: ms
    - button "Toggle Component Inspector" [ref=e31] [cursor=pointer]:
      - img [ref=e32]
```