# Dolivroo Shipping for n8n

Official n8n community node for Dolivroo - Unified shipping API for Algeria.

## Installation

### Via n8n Community Nodes (Recommended)
1. Go to **Settings → Community Nodes**
2. Click **Install a community node**
3. Enter: `n8n-nodes-dolivroo`
4. Click **Install**

### Manual Installation
```bash
cd ~/.n8n/custom
npm install n8n-nodes-dolivroo
```

## Configuration

1. In n8n, go to **Credentials → Add Credential**
2. Select **Dolivroo API**
3. Enter your API key from [dolivroo.com/dashboard/developer](https://dolivroo.com/dashboard/developer)

## Available Operations

### Parcel
- **Create** - Create a new shipping parcel
- **Get** - Get parcel details by tracking ID
- **Cancel** - Cancel an existing parcel
- **Get Label** - Download shipping label (PDF)

### Rates
- **Get Rates** - Get shipping rates from origin to destination

### Companies
- **List** - Get all available delivery companies

## Example Workflow

```json
{
  "nodes": [
    {
      "name": "Create Parcel",
      "type": "n8n-nodes-dolivroo.dolivroo",
      "parameters": {
        "operation": "createParcel",
        "provider": "yalidine",
        "customerName": "Ahmed Ben Ali",
        "customerPhone": "0555123456",
        "destinationWilaya": "Alger",
        "destinationCommune": "Bab El Oued",
        "productDescription": "Electronics",
        "amount": 5000
      }
    }
  ]
}
```

## Support

- Documentation: [docs.dolivroo.com](https://docs.dolivroo.com)
- Issues: [github.com/dolivroo/n8n-nodes-dolivroo/issues](https://github.com/dolivroo/n8n-nodes-dolivroo/issues)

## License

MIT
